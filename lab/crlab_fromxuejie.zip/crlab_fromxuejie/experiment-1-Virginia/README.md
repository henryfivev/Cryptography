# Cryptography-experiment
第一次实验不是很难</br>
记得当时做注意一下mod 26，网上查到的答案是错的</br>
其他就是照着书上说的原理打就行</br>
