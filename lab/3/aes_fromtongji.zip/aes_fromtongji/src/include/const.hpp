#include <vector>
#include <bitset>
#include <cassert>
using std::vector;
using byte = std::bitset<8>;

extern const vector<byte> rcon;
extern const vector<byte> s_box;