#include "const.hpp"

vector<byte> SubBytes(vector<byte> input);