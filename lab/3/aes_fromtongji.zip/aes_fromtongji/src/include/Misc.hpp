#include "const.hpp"

vector<byte> byte_to_vector(std::bitset<128> input);
vector<vector<byte>> vector_to_2_vector(vector<byte> input);