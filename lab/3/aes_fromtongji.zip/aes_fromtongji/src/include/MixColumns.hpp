#include "const.hpp"
#include "Misc.hpp"

vector<byte> MixColumns(vector<byte>);