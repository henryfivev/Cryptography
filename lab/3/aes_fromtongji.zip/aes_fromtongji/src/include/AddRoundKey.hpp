#include "const.hpp"

vector<byte> AddRoundKey(vector<byte>, vector<byte>);