# MersenneTwister-go
伪随机数生成 GO语言版梅森旋转算法

```
mt := mt_random.NewMersenneTwister(0)
fmt.Println(mt.Rand())
```
