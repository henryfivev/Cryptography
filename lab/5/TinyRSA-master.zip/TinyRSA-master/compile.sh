#/bin/sh

clear; clear
sudo g++ rsa.cpp TinyRSA.cpp TinyRSA.h -lgmpxx -lgmp